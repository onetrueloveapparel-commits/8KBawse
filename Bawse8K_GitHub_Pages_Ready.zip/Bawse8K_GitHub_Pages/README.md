# Bawse 8K — GitHub Pages Website

This is the GitHub Pages-ready version of the Bawse 8K ordering website.

## What is included
- Professional black/gold Bawse 8K landing page
- Annual Plan — $150/year
- Monthly Plan — $50/month
- Customer order form
- Device selection
- Customer contact information and notes
- Bawse 8K promotional artwork
- Mobile-friendly layout
- No server or database required for the static order form
- `.nojekyll` file for straightforward GitHub Pages publishing

## Publish on GitHub Pages

1. Sign in to GitHub.
2. Create a new repository. Example: `bawse8k-website`
3. Upload **all files and folders inside this package**. Make sure `index.html` is in the repository's top level.
4. Open the repository's **Settings → Pages**.
5. Under the publishing/source option, select **Deploy from a branch**.
6. Select the `main` branch and the `/ (root)` folder, then save.
7. GitHub will provide the live `github.io` website address after the site finishes publishing.

GitHub Pages supports static HTML, CSS and JavaScript sites and is available with GitHub Free for public repositories.

## Order form

The site remains an **order/intake form**. When a customer submits it, the form opens an email addressed to:

`orders@bawse8k.com`

If that is not the correct business email, edit the email address near the bottom of `index.html` before publishing.

## Payments later

The website does **not** include Stripe yet. This version intentionally keeps the customer order form. Stripe can be added later without changing the overall design.

For live payments, use a payment flow that does not expose private payment credentials in the website's HTML or JavaScript.

## Custom domain later

You can keep the free GitHub Pages address or connect a domain you own later. GitHub Pages supports custom domains.
